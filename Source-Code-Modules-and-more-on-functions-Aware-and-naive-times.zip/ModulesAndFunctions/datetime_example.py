import datetime as dt
from datetime import datetime

now = datetime.now()
utc_now = datetime.utcnow()

print(now)
print(utc_now)
