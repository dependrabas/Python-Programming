import webbrowser

# webbrowser.open('https://docs.python.org/3.10/library/webbrowser')

# chrome = webbrowser.get(using='google-chrome')
chrome = webbrowser.get('C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s')
chrome.open('https://learnprogramming.academy/courses')
